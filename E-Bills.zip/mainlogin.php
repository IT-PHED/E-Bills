<?php require_once('Connections/conKachi.php'); ?>
<?php 
session_start();
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=$_POST['password'];
  $password=sha1($password);
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "buyerdash.php";
  $MM_redirectLoginFailed = "login.php?vl=001n";
  $MM_redirecttoReferrer = false;
  mysqli_select_db($conKachi, $database_conKachi);
  
  $LoginRS__query=sprintf("SELECT email, password, seller_id FROM vendor WHERE (email=%s OR seller_id='$loginUsername') AND password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysqli_query($conKachi,$LoginRS__query) or die(mysqli_error($conKachi));
  $row_LoginRS = mysqli_fetch_assoc($LoginRS);;
  $loginFoundUser = mysqli_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username1'] = $row_LoginRS['seller_id'];
    $_SESSION['MM_UserGroup1'] = $loginStrGroup;	      

    	$colname_Recordset1 = "-1";
if (isset($_SESSION['MM_Username1'])) {
  $colname_Recordset1 = $_SESSION['MM_Username1'] ;
}
header('location:./');
  } else {
	header('location:mainlogin.php?vl=001n');  
  }
}
?>
<!DOCTYPE html><html lang="en-US" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="pingback" href="xmlrpc.php"> <script>document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script> <link type="text/css" media="all" href="wp-content/cache/autoptimize/29/css/autoptimize_13cb1b628b875df2315401fdca857f0e.css" rel="stylesheet" />
<title>My account &#8211; AriariaOnline &#8211; The online marketplace for Ariaria International Market</title><meta name='robots' content='noindex,follow' /><link rel='dns-prefetch' href='//maps.googleapis.com' /><link href='https://fonts.gstatic.com' crossorigin='anonymous' rel='preconnect' /><link href='https://ajax.googleapis.com' rel='preconnect' /><link href='https://fonts.googleapis.com' rel='preconnect' /><link rel="alternate" type="application/rss+xml" title="Martfury - Multi-Vendor &amp; Marketplace eCommerce &raquo; Feed" href="feed/" /><link rel="alternate" type="application/rss+xml" title="Martfury - Multi-Vendor &amp; Marketplace eCommerce &raquo; Comments Feed" href="comments/feed/" /> <!--[if lt IE 9]><link rel='stylesheet' id='vc_lte_ie9-css'  href='wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css' type='text/css' media='screen' /> <![endif]--> <script type="text/template" id="tmpl-variation-template"><div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div></script> <script type="text/template" id="tmpl-unavailable-variation-template"><p>Sorry, this product is unavailable. Please choose a different combination.</p></script> <script type='text/javascript'>var dokan = {"ajaxurl":"http:\/\/demo2.drfuri.com\/martfury\/wp-admin\/admin-ajax.php","nonce":"0d8d8ee159","ajax_loader":"http:\/\/demo2.drfuri.com\/martfury\/wp-content\/plugins\/dokan-lite\/assets\/images\/ajax-loader.gif","seller":{"available":"Available","notAvailable":"Not Available"},"delete_confirm":"Are you sure?","wrong_message":"Something went wrong. Please try again.","vendor_percentage":"90","commission_type":"percentage","rounding_precision":"6","mon_decimal_point":".","i18n_choose_featured_img":"Upload featured image","i18n_choose_file":"Choose a file","i18n_choose_gallery":"Add Images to Product Gallery","i18n_choose_featured_img_btn_text":"Set featured image","i18n_choose_file_btn_text":"Insert file URL","i18n_choose_gallery_btn_text":"Add to gallery","duplicates_attribute_messg":"Sorry, this attribute option already exists, Try a different one.","variation_unset_warning":"Warning! This product will not have any variations if this option is not checked.","new_attribute_prompt":"Enter a name for the new attribute term:","remove_attribute":"Remove this attribute?","dokan_placeholder_img_src":"http:\/\/demo2.drfuri.com\/martfury\/wp-content\/plugins\/woocommerce\/assets\/images\/placeholder.png","add_variation_nonce":"7aef06c404","link_variation_nonce":"202dae958a","delete_variations_nonce":"8cd05f39ef","load_variations_nonce":"3fa1cb01fc","save_variations_nonce":"8746d141da","bulk_edit_variations_nonce":"08acec8c4c","i18n_link_all_variations":"Are you sure you want to link all variations? This will create a new variation for each and every possible combination of variation attributes (max 50 per run).","i18n_enter_a_value":"Enter a value","i18n_enter_menu_order":"Variation menu order (determines position in the list of variations)","i18n_enter_a_value_fixed_or_percent":"Enter a value (fixed or %)","i18n_delete_all_variations":"Are you sure you want to delete all variations? This cannot be undone.","i18n_last_warning":"Last warning, are you sure?","i18n_choose_image":"Choose an image","i18n_set_image":"Set variation image","i18n_variation_added":"variation added","i18n_variations_added":"variations added","i18n_no_variations_added":"No variations added","i18n_remove_variation":"Are you sure you want to remove this variation?","i18n_scheduled_sale_start":"Sale start date (YYYY-MM-DD format or leave blank)","i18n_scheduled_sale_end":"Sale end date (YYYY-MM-DD format or leave blank)","i18n_edited_variations":"Save changes before changing page?","i18n_variation_count_single":"%qty% variation","i18n_variation_count_plural":"%qty% variations","i18n_no_result_found":"No Result Found","variations_per_page":"10","store_banner_dimension":{"width":625,"height":300,"flex-width":true,"flex-height":true},"selectAndCrop":"Select and Crop","chooseImage":"Choose Image","product_title_required":"Product title is required","product_category_required":"Product category is required","search_products_nonce":"4058f7d237","search_customer_nonce":"9b6716869e","i18n_matches_1":"One result is available, press enter to select it.","i18n_matches_n":"%qty% results are available, use up and down arrow keys to navigate.","i18n_no_matches":"No matches found","i18n_ajax_error":"Loading failed","i18n_input_too_short_1":"Please enter 1 or more characters","i18n_input_too_short_n":"Please enter %qty% or more characters","i18n_input_too_long_1":"Please delete 1 character","i18n_input_too_long_n":"Please delete %qty% characters","i18n_selection_too_long_1":"You can only select 1 item","i18n_selection_too_long_n":"You can only select %qty% items","i18n_load_more":"Loading more results\u2026","i18n_searching":"Searching\u2026","i18n_date_format":"M dS Y","rest":{"root":"http:\/\/demo2.drfuri.com\/martfury\/wp-json\/","nonce":"059efaa704","version":"dokan\/v1"},"api":null,"libs":[],"routeComponents":{"default":null},"routes":[]};</script> <script type='text/javascript' src='wp-includes/js/jquery/jquery.js'></script> <script type='text/javascript'>var wc_add_to_cart_params = {"ajax_url":"\/martfury\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/martfury\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/demo2.drfuri.com\/martfury\/cart\/","is_cart":"","cart_redirect_after_add":"no"};</script> <script type='text/javascript'>var _zxcvbnSettings = {"src":"http:\/\/demo2.drfuri.com\/martfury\/wp-includes\/js\/zxcvbn.min.js"};</script> <!--[if lt IE 9]> <script type='text/javascript' src='wp-content/themes/martfury/js/plugins/html5shiv.min.js'></script> <![endif]--> <!--[if lt IE 9]> <script type='text/javascript' src='wp-content/themes/martfury/js/plugins/respond.min.js'></script> <![endif]--> <!--[if lt IE 8]> <script type='text/javascript' src='wp-includes/js/json2.min.js'></script> <![endif]--><link rel='https://api.w.org/' href='wp-json/' /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc.php?rsd" /><link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wp-includes/wlwmanifest.xml" /><meta name="generator" content="WordPress 5.2.4" /><meta name="generator" content="WooCommerce 3.6.5" /><link rel="canonical" href="my-account/" /><link rel='shortlink' href='?p=7' /><link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embed?url=http%3A%2F%2Fdemo2.drfuri.com%2Fmartfury%2Fmy-account%2F" /><link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embed?url=http%3A%2F%2Fdemo2.drfuri.com%2Fmartfury%2Fmy-account%2F&#038;format=xml" />  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-86661239-4"></script> <script>window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-86661239-4');</script> <noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
  <meta name='robots' content='noindex,follow' />
<link rel="icon" href="wp-content/uploads/sites/29/2018/02/favi.png" sizes="32x32" />
  <link rel="icon" href="wp-content/uploads/sites/29/2018/02/favi.png" sizes="192x192" />
  <link rel="apple-touch-icon-precomposed" href="wp-content/uploads/sites/29/2018/02/favi.png" />
  <meta name="msapplication-TileImage" content="wp-content/uploads/sites/29/2018/02/favi.png" /> <script type="text/javascript">function setREVStartSize(e){
				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
				}catch(d){console.log("Failure at Presize of Slider:"+d)}
			};</script> <noscript><style>.wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><meta property="og:locale" content="en_US"/><meta property="og:site_name" content="Martfury - Multi-Vendor &amp; Marketplace eCommerce"/><meta property="og:title" content="My account"/><meta property="og:url" content="my-account/"/><meta property="og:type" content="article"/><meta property="og:description" content="My account"/><meta property="og:image" content="wp-content/uploads/sites/29/2019/05/s3-1.jpg"/><meta property="og:image:url" content="wp-content/uploads/sites/29/2019/05/s3-1.jpg"/><meta property="article:author" content="#"/><meta property="article:publisher" content="https://www.facebook.com"/><meta itemprop="name" content="My account"/><meta itemprop="headline" content="My account"/><meta itemprop="description" content="My account"/><meta itemprop="image" content="wp-content/uploads/sites/29/2019/05/s3-1.jpg"/><meta itemprop="author" content="drfurion"/><meta name="twitter:title" content="My account"/><meta name="twitter:url" content="my-account/"/><meta name="twitter:description" content="My account"/><meta name="twitter:image" content="wp-content/uploads/sites/29/2019/05/s3-1.jpg"/><meta name="twitter:card" content="summary_large_image"/><meta name="twitter:creator" content="@#"/></head>
			<body class="page-template-default wp-embed-responsive woocommerce-account woocommerce-page woocommerce-no-js header-layout-3 
			full-content mf-preloader sticky-header account-page-promotion wpb-js-composer js-comp-ver-6.0.3 vc_responsive dokan-theme-martfury">
    <script src="abashops.js"></script>
			
			<div id="page" class="hfeed site">
			<div id="martfury-preloader" class="martfury-preloader"></div>
			<style>
			.account-page-promotion .customer-login .tabs-navn {
    border-bottom: 1px solid #e8e8e8;
    display: flex;
    align-items: center;
}
.woocommerce .customer-login .tabs-navn {
    text-align: center;
    margin-bottom: 30px;
}
.martfury-tabs .tabs-nav, .martfury-login-tabs .tabs-navn {
    margin: 0;
    padding: 0;
    overflow: hidden;
    list-style-type: none;
}
.account-page-promotion .customer-login .tabs-navn li {
    margin-bottom: 0;
    padding: 25px 10px;
    width: 50%;
    position: relative;
}

.woocommerce .customer-login .tabs-navn li {
    float: none;
    display: inline-block;
}
.martfury-tabs .tabs-nav li, .martfury-login-tabs .tabs-navn li {
    float: left;
}
li {
    margin-bottom: 7px;
}
.account-page-promotion .customer-login .tabs-navn a.active {
    color: #fcb800;
}

.account-page-promotion .customer-login .tabs-navn a {
    line-height: 1;
    font-size: 24px;
    padding: 0;
}
.woocommerce .customer-login .tabs-navn a {
    font-size: 30px;
    color: #999;
    padding: 0 20px;
    font-weight: 600;
}
.martfury-tabs .tabs-nav a, .martfury-login-tabs .tabs-navn a {
    display: block;
}
.account-page-promotion .customer-login .tabs-navn a.active:after {
    opacity: 1;
}
.account-page-promotion .customer-login .tabs-navn a:after {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    content: "";
    border-bottom: 2px solid #fcb800;
    opacity: 0;
}
</style>
			<?php include 'header.php';?>
<div class="page-header page-header-page hide-title"><div class="page-breadcrumbs"><div class="container"><ul class="breadcrumbs"><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"> <a class="home" href="https://ariaria.com.ng" itemprop="item">
<span itemprop="name">Home </span></a></li><span class="sep">/</span>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"> 
<span itemprop="item"><span itemprop="name">My Shop</span></span></li></ul></div></div><h1 class="entry-title">My account</h1></div><div id="content" class="site-content"><div class="container"><div class="row"><div id="primary" class="content-area col-md-12"><main id="main" class="site-main"><article id="post-7" class="post-7 page type-page status-publish hentry"><div class="entry-content"><div class="woocommerce"><div class="woocommerce-notices-wrapper"></div><div class="customer-login"><div class="row">
<div class="col-md-5 col-sm-12 col-login">
<div class="martfury-login-promotion martfury-login-tabs">
<ul class="tabs-navn"><li class="active">
<a href="#" class="active">Log in</a></li><li><a  href="https://ariaria.com.ng/become-a-vendor">Register</a></li></ul>
<div class="tabs-content">
<div class="tabs-panel active"><h2>Log In Your Account</h2>
<?php if(isset($_GET['vl'])) {
	echo '<span style="color:red;font-weight:bolder">Invalid login</span>';
} ?>
<form class="woocommerce-form woocommerce-form-login login" method="post"><p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide"> <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" required
 placeholder="Username or email address"
 name="username" id="username" autocomplete="username"
 value=""/></p><p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide form-row-password"> <input class="woocommerce-Input woocommerce-Input--text input-text" required
 placeholder="Password" type="password" autocomplete="current-password"
 name="password" id="password"/> <a class="lost-password"
 href="Forget_password">Forgot?</a></p><p class="form-row"> <label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme"> <input class="woocommerce-form__input woocommerce-form__input-checkbox"
 name="rememberme" type="checkbox" id="rememberme" value="forever"/> <span>Remember me</span> </label> <input type="hidden" id="woocommerce-login-nonce" name="woocommerce-login-nonce" value="4155764211" /><input type="hidden" name="_wp_http_referer" value="/martfury/my-account/" />
 <button type="submit" class="woocommerce-Button button" name="login" value="Log in">Log in</button></p></form></div>
 <div class="tabs-panel "><h2>Register An Account</h2>
 <form method="post" id="register-form" class="register woocommerce-form woocommerce-form-register">
 <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide"> 
 <input type="email" required
 class="woocommerce-Input woocommerce-Input--text input-text"
 placeholder="Email address"
 name="email" id="reg_email" autocomplete="email"
 value=""/></p><p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide"> 
 <input type="password" required
 placeholder="Password"
 class="woocommerce-Input woocommerce-Input--text input-text" autocomplete="new-password"
 name="password" id="reg_password"/></p>
 <div class="show_if_seller" style="display:none">
 <div class="split-row form-row-wide">
 <p class="form-row form-group"> <label for="first-name">First Name <span class="required">*</span></label> 
 <input type="text" class="input-text form-control" name="fname" id="first-name" value="" required="required" /></p>
 <p class="form-row form-group"> <label for="last-name">Last Name <span class="required">*</span></label> 
 <input type="text" class="input-text form-control" name="lname" id="last-name" value="" required="required" /></p></div>
 <p class="form-row form-group form-row-wide"> <label for="company-name">Shop Name <span class="required">*</span></label> 
 <input type="text" class="input-text form-control" name="shopname" id="company-name" value="" required="required" /></p>
 <p class="form-row form-group form-row-wide"> 
 <label for="seller-url" class="pull-left">Username/Shop URL <span class="required">*</span></label> <strong id="url-alart-mgsn" class="pull-right"></strong> 
 <input type="text" class="input-text form-control" name="shopurl" id="seller-url" value="" required="required" /> <small>ariaria.com.ng/<strong id="url-alart"></strong>
 </small></p>
 <p class="form-row form-group form-row-wide"> <label for="shop-phone">Phone Number <span class="required">*</span></label> 
 <input type="text" class="input-text form-control" name="phone" id="shop-phone" value="" required="required" /></p>
 </div>
 <p class="form-row form-group user-role"> <label class="radio woocommerce-form__label-for-checkbox"> <input type="radio" name="role" class="woocommerce-form__input-checkbox" value="customer" checked='checked'> <span> I am a Seller </span> </label> <label class="radio woocommerce-form__label-for-checkbox"> <input type="radio" name="role" class="woocommerce-form__input-checkbox" value="seller"> <span> I am a vendor </span> </label></p>
 
 <div class="woocommerce-privacy-policy-text"><p>Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our <a href="policy/" class="woocommerce-privacy-policy-link" target="_blank">privacy policy</a>.</p></div>
 <p class="woocommerce-FormRow form-row"> <input type="hidden" id="woocommerce-register-nonce" name="woocommerce-register-nonce" value="543cc583e3" />
 <input type="hidden" name="_wp_http_referer" value="/martfury/my-account/" /> 
 <button type="submit" class="woocommerce-Button button" name="register"
 value="Register">Register</button></p>
 </form>
 </div></div></div></div><div class="col-md-6 col-sm-12 col-md-offset-1 col-login-promotion"><div class="login-promotion"><h2 class="pro-title">Sign up today and you will be able to:</h2><p class="pro-text">AriariaOnline Buyer Protection has you covered from click to delivery. Sign up or sign in and you will be able to:</p><div class="pro-list"><ul><li><i class="icon-credit-card"></i>SPEED YOUR WAY THROUGH CHECKOUT</li><li><i class="icon-clipboard-check"></i>TRACK YOUR ORDERS EASILY</li><li><i class="icon-bag2"></i>KEEP A RECORD OF ALL YOUR PURCHASES</li></ul></div><div class="pro-sep"></div>
 <!--
 <div class="promotion-ads-content"><h2 class="promotion-ads-title">&#8358;2,500</h2><div class="promotion-ads-text"><h4>A small gift for your first purchase</h4> Martfury give &#8358;2,500 as a small gift for your first purchase. Welcome to Martfury!</div>
 </div>-->
 </div></div></div></div></div></div></article></main></div></div></div></div>
 
<?php include 'footer.php';?>
</div>

 <div id="pswp" class="pswp" tabindex="-1" aria-hidden="true"><div class="pswp__bg"></div><div class="pswp__scroll-wrap"><div class="pswp__container"><div class="pswp__item"></div><div class="pswp__item"></div><div class="pswp__item"></div></div><div class="pswp__ui pswp__ui--hidden"><div class="pswp__top-bar"><div class="pswp__counter"></div> <button class="pswp__button pswp__button--close"
 title="Close (Esc)"></button> <button class="pswp__button pswp__button--share"
 title="Share"></button> <button class="pswp__button pswp__button--fs"
 title="Toggle fullscreen"></button> <button class="pswp__button pswp__button--zoom"
 title="Zoom in/out"></button><div class="pswp__preloader"><div class="pswp__preloader__icn"><div class="pswp__preloader__cut"><div class="pswp__preloader__donut"></div></div></div></div></div><div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap"><div class="pswp__share-tooltip"></div></div> <button class="pswp__button pswp__button--arrow--left"
 title="Previous (arrow left)"> </button> <button class="pswp__button pswp__button--arrow--right"
 title="Next (arrow right)"> </button><div class="pswp__caption"><div class="pswp__caption__center"></div></div></div></div></div><div id="mf-quick-view-modal" class="mf-quick-view-modal martfury-modal woocommerce" tabindex="-1"><div class="mf-modal-overlay"></div><div class="modal-content"> <a href="#" class="close-modal"> <i class="icon-cross"></i> </a><div class="product-modal-content"></div></div><div class="mf-loading"></div></div> <a id="scroll-top" class="backtotop" href="#page-top"> <i class="arrow_carrot_up_alt"></i> </a>
 

 <div id="mf-off-canvas-layer" class="martfury-off-canvas-layer"></div> <script>(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
	for( var j=0; j < urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder & pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
	for(var i=0; i<dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();</script> <script type="text/javascript">var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;</script> <script type='text/javascript'>var yith_wcwl_l10n = {"ajax_url":"\/martfury\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","multi_wishlist":"","hide_add_button":"1","is_user_logged_in":"","ajax_loader_url":"http:\/\/demo2.drfuri.com\/martfury\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader.gif","remove_from_wishlist_after_add_to_cart":"yes","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies are enabled on your browser.","added_to_cart_message":"<div class=\"woocommerce-message\">Product correctly added to cart<\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","move_to_another_wishlist_action":"move_to_another_wishlsit","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem"}};</script> <script type='text/javascript'>var wpcf7 = {"apiSettings":{"root":"http:\/\/demo2.drfuri.com\/martfury\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};</script> <script type='text/javascript'>var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};</script> <script type='text/javascript'>var wc_password_strength_meter_params = {"min_password_strength":"3","i18n_password_error":"Please enter a stronger password.","i18n_password_hint":"Hint: The password should be at least twelve characters long. To make it stronger, use upper and lower case letters, numbers, and symbols like ! \" ? $ % ^ & )."};</script> <script type='text/javascript'>var woocommerce_params = {"ajax_url":"\/martfury\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/martfury\/?wc-ajax=%%endpoint%%"};</script> <script type='text/javascript'>var wc_cart_fragments_params = {"ajax_url":"\/martfury\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/martfury\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_6b9dfd5a4b8e7d0b606aa8d49addcd15","fragment_name":"wc_fragments_6b9dfd5a4b8e7d0b606aa8d49addcd15","request_timeout":"5000"};</script> <script type='text/javascript'>var yith_woocompare = {"ajaxurl":"\/martfury\/?wc-ajax=%%endpoint%%","actionadd":"yith-woocompare-add-product","actionremove":"yith-woocompare-remove-product","actionview":"yith-woocompare-view-table","actionreload":"yith-woocompare-reload-product","added_label":"Browse Compare","table_title":"Product Comparison","auto_open":"yes","loader":"http:\/\/demo2.drfuri.com\/martfury\/wp-content\/plugins\/yith-woocommerce-compare\/assets\/images\/loader.gif","button_text":"Compare","cookie_name":"yith_woocompare_list_29","close_label":"Close"};</script> <script type='text/javascript'>var _wpUtilSettings = {"ajax":{"url":"\/martfury\/wp-admin\/admin-ajax.php"}};</script> <script type='text/javascript'>var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/martfury\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};</script> <script type='text/javascript'>var martfuryData = {"direction":"false","ajax_url":"http:\/\/demo2.drfuri.com\/martfury\/wp-admin\/admin-ajax.php","nonce":"03bcd2c6f0","currency_pos":"left","currency_symbol":"$","thousand_sep":",","decimal_sep":".","price_decimals":"2","days":"days","hours":"hours","minutes":"minutes","seconds":"seconds","product_degree":"","add_to_cart_ajax":"1","search_content_type":"product","nl_days":"1","nl_seconds":"0","added_to_cart_notice":"1","product_gallery":"1","ajax_search":"1","collapse_the_filter":{"collapse":0,"status":"close"},"collapse_tab":{"collapse":0,"status":"close"},"quantity_ajax":"","l10n":{"notice_text":"has been added to your cart.","notice_texts":"have been added to your cart.","cart_text":"View Cart","cart_link":"http:\/\/demo2.drfuri.com\/martfury\/cart\/","cart_notice_auto_hide":3000}};</script> <script type='text/javascript'>var tawcDeals = {"l10n":{"days":"Days","hours":"Hours","minutes":"Minutes","seconds":"Seconds"}};</script> <script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?key=AIzaSyA7_-dqBdPznv5nSNhB9pYhB4zj1e9ZV7s&#038;ver=5.2.4'></script> <script type='text/javascript'>jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"M ddS yy","firstDay":1,"isRTL":false});});</script> <script type='text/javascript'>var DokanValidateMsg = {"required":"This field is required","remote":"Please fix this field.","email":"Please enter a valid email address.","url":"Please enter a valid URL.","date":"Please enter a valid date.","dateISO":"Please enter a valid date (ISO).","number":"Please enter a valid number.","digits":"Please enter only digits.","creditcard":"Please enter a valid credit card number.","equalTo":"Please enter the same value again.","maxlength_msg":"Please enter no more than {0} characters.","minlength_msg":"Please enter at least {0} characters.","rangelength_msg":"Please enter a value between {0} and {1} characters long.","range_msg":"Please enter a value between {0} and {1}.","max_msg":"Please enter a value less than or equal to {0}.","min_msg":"Please enter a value greater than or equal to {0}."};</script> <script type='text/javascript'>var tawcvs = {"tooltip":"yes"};</script> <script type='text/javascript'>var martfuryShortCode = {"days":"days","hours":"hours","minutes":"minutes","seconds":"seconds","direction":"false"};</script> <script type='text/javascript'>var mc4wp_forms_config = [];</script> <!--[if lte IE 9]> <script type='text/javascript' src='wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js'></script> <![endif]-->
		
		
 
 <script type="text/javascript" defer src="wp-content/cache/autoptimize/29/js/autoptimize_c5c5d63d4cbbaea70e800439ca911d9d.js"></script>
 <script>
 $("#register-form").on('submit', function(e) {
				e.preventDefault();	
 		var am = $('#seller-url').val();
		$.post('checkdata.php', {'seller-url' : am}, function(data) {
        if(data=='notexist') {  
				var formd = $('#register-form').serialize();
		   $.ajax({
        type:'post',
        url:'reg.php',
        data:formd,
        success:function(data) {
		var valData= data;
		var valNew=valData.split(']');
	    var des=valNew[1];
		if(des=='1') {
	window.location.href="Shop_Set/1"; //append data into #results element
		}
        }
      });
		} else {
alert('Please Check your Shop URL');			
		}
 });
 });
 
   $("#seller-url").on("change paste keyup", function() {
			
 		var am = $('#seller-url').val();
		$.post('checkdata.php', {'seller-url' : am}, function(data) {
        if(data=='notexist') {  
            $('#url-alart-mgsn').empty();
            $('#url-alart-mgsn').append('Available');
		} else {
		    $('#url-alart-mgsn').empty();
            $('#url-alart-mgsn').append('Unavailable');	
		}
 
});
   });
 </script></body></html>