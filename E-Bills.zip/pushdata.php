<?php
session_start();

$ch = curl_init();
$certificate_location = 'cacert.pem';

curl_setopt($ch, CURLOPT_URL,"https://localhost:44382/api/UploadPIPMAPs");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "lvl=");
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));


// receive server response ...
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$server_output = curl_exec ($ch);
curl_close ($ch);

$authorization = "Authorization: Bearer ".$_SESSION['MM_Username1'];  
$array = json_decode($server_output, true); //decode the JSON response
$data = $array["data"];
$postRequest = array(
  'data' => $data,
  'companyId' => 30
);
  //SEND DATA TO API
  $jsonArrayRequest = json_encode($postRequest);
  //print_r($jsonArrayRequest);
  $cURLConnection = curl_init('https://signals-api.staging.vggdev.com/metricentries/push/');
  $certificate_location = 'cacert.pem';
  curl_setopt($cURLConnection, CURLOPT_HTTPHEADER, array('Content-Type: application/json' , $authorization ));
  curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $jsonArrayRequest);
  curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($cURLConnection, CURLOPT_SSL_VERIFYHOST, $certificate_location);
  curl_setopt($cURLConnection, CURLOPT_SSL_VERIFYPEER, $certificate_location);
  
  $apiResponse = curl_exec($cURLConnection);
  curl_close($cURLConnection);
  
  // $apiResponse - available data from the API request
  $jsonArrayResponse = json_decode($apiResponse);
    $array = json_decode($apiResponse, true);
    if(isset($array["message"])){ 
  $err_c = $array["message"];
  if($err_c =="Your push was successful, we'll start processing your push and notify you upon completion") {
echo ']1]';
  }}
 ?>
