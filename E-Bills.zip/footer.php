
        <footer>
          <div class="pull-right">
            Powered by SMAC House Of Fashion</a>
          </div>
          <div class="clearfix"></div>
        </footer>