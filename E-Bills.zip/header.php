	<header id="site-header" class="site-header ">
		<div class="header-main-wapper">
    <div class="header-main">
        <div class="martfury-container">
            <div class="row header-row">
                <div class="header-logo col-md-3 col-sm-3">
                    <div class="d-logo">
						    <div class="logo">
        <a href="./">
            <img class="site-logo" alt="AriariaOnline Logo" src="wp-content/uploads/sites/38/2018/01/logo_light2.png"/>
			        </a>
    </div>
<h1 class="site-title"><a href="" rel="home"></a></h1>    <h2 class="site-description"></h2>

                    </div>
					                        <div class="d-department hidden-xs hidden-sm">
							        <div class="products-cats-menu close">
           

            
        </div>
		                        </div>
					                </div>
                <div class="header-extras col-md-9 col-sm-9">
				                    <ul class="extras-menu">
						<!--<li class="extra-menu-item menu-item-compare menu-item-yith">
				<a class="yith-contents yith-woocompare-open" href="#">
					<i class="icon-chart-bars extra-icon"></i>
					<span class="mini-item-counter" id="mini-compare-counter">
						0
					</span>
				</a>
			</li>-->
			</ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="main-menu hidden-xs hidden-sm">
    <div class="martfury-container">
        <div class="row header-row">
			                <div class="col-md-3 col-sm-3 i-product-cats mr-extra-department">
					        <div class="products-cats-menu close">
            
            
        </div>
		                </div>
			            <div class="col-md-9 col-sm-9 col-nav-menu mr-header-menu">
				                  
								        <div class="header-bar topbar">
			<div id="custom_html-4" class="widget_text widget widget_custom_html">
			<div class="textwidget custom-html-widget"> 
		</div>
			</div>
			<!--<div id="custom_html-3" class="widget_text widget widget_custom_html">
			<div class="textwidget custom-html-widget"> <a href="order-tracking">Track Your Order</a></div></div>-->
			<div id="custom_html-3" class="widget_text widget widget_custom_html">
			<div class="textwidget custom-html-widget"> </div></div>
			
			<!--<div id="custom_html-11" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><div class="mf-currency-widget">				
	<div class="widget-currency">
			<span class="current">US Dollar</span><ul><li class="actived"><a href="#" class="woocs_flag_view_item woocs_flag_view_item_current" data-currency="USD">US Dollar</a></li>
	<li><a href="#" class="woocs_flag_view_item" data-currency="EUR">European Euro</a></li></ul>		</div>
	
		</div></div></div>
		<div id="custom_html-5" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><div id="lang_sel">
					<ul>
						<li>
							<a href="#" class="lang_sel_sel icl-en">
								<img class="iclflag" src="wp-content/uploads/sites/29/2018/01/en.png" alt="en" title="English">
								English
							</a>
						 	<ul>
								<li class="icl-fr">
									<a href="fr/">
										<img class="iclflag" src="wp-content/uploads/sites/29/2018/01/fr.png" alt="fr" title="French">
										French
									</a>
								</li>
								<li class="icl-de">
									<a href="de/">
										<img class="iclflag" src="wp-content/uploads/sites/29/2018/01/de.png" alt="de" title="German">
										German
									</a>
								</li>
							</ul>
						</li>
					</ul>
				</div></div></div>  -->
				</div>
		            </div>
        </div>
    </div>
</div>
<div class="mobile-menu hidden-lg hidden-md">
    <div class="container">
        <div class="mobile-menu-row">
          
		      </div>
    </div>
</div>
	</header>
	<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ea0353f35bcbb0c9ab39738/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->