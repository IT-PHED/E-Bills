<?php
session_start();
if(isset($_POST['action']) && ($_POST['action']=="login")) {
	
		$email  = $_POST['email'];	
		$role  = $_POST['password'];			 
	 
        $postRequest = array(
            'username' => $email,
            'password' => $role,
            'grant_type' => "password"
          );
          
          //SEND DATA TO API
          //$jsonArrayRequest = json_encode($postRequest);
          $jsonArrayRequest = json_encode($postRequest);
          $cURLConnection = curl_init('https://signals-api.staging.vggdev.com/extintegration/api/');
          $certificate_location = 'cacert.pem';
          //curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json' , $authorization ));
          curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $jsonArrayRequest);
          curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($cURLConnection, CURLOPT_SSL_VERIFYHOST, $certificate_location);
          curl_setopt($cURLConnection, CURLOPT_SSL_VERIFYPEER, $certificate_location);
          
           echo $apiResponse = curl_exec($cURLConnection);
          curl_close($cURLConnection);
          
          // $apiResponse - available data from the API request
          $jsonArrayResponse = json_decode($apiResponse);
            $array = json_decode($apiResponse, true);
          echo $err_c = $array["data"]["access_token"];
          if(isset($array["data"]["access_token"])){
              $_SESSION['MM_Username1'] = $array["data"]["access_token"];
              $_SESSION['MM_UserGroup1'] = NULL;
            echo ']1';
          }
/**
$ch = curl_init();
$certificate_location = 'cacert.pem';

curl_setopt($ch, CURLOPT_URL,"https://signals-api.staging.vggdev.com/extintegration/api/");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "grant_type=password&username=".$email."&password=".$role);
			

curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));


// receive server response ...
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

  $server_output = curl_exec ($ch);
curl_close ($ch);


 $array = json_decode($server_output, true); //decode the JSON response

 if(isset($array['access_token'])){

	 $_SESSION['access_token']=$array['access_token'];
	 $_SESSION['MM_UserGroup1']="";
    echo ']1';

 }	else {
	 echo ']zz';
 }*/
	
}
?>