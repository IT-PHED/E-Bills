<?php
session_start();
require_once('Connections/conKachi.php');
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
 

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username1'] = NULL;
  $_SESSION['MM_UserGroup1'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username1']);
  unset($_SESSION['MM_UserGroup1']);
  unset($_SESSION['PrevUrl']);
  unset($_SESSION['name']);
	
  $logoutGoTo = "Login";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}

$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "Login";
if (!((isset($_SESSION['MM_Username1'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username1'], $_SESSION['MM_UserGroup1'])))) {   
  header("Location: ". $MM_restrictGoTo); 
  exit;
}

    	$colname_Recordset1 = "-1";
if (isset($_SESSION['MM_Username1'])) {
  $colname_Recordset1 = $_SESSION['MM_Username1'];
}


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>PIPMAPs</title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    <link href="vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">
<script src="abashops.js"></script>
		
	<!--	<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" type="text/css" href="pixelarity.css">
		<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha384-vk5WoKIaW/vJyUAd9n/wmopsmNhiy+L2Z+SBxGYnUkunIxVxAv/UtMOhba/xskxh" crossorigin="anonymous"></script>
		<script type="text/javascript" src="pixelarity-face.js"></script>
		<script type="text/javascript" src="script-face.js"></script>-->
			<style type="text/css">
			#result{
				display: block;
				position: relative;
				margin-top: 40px;
			}
			.face{
				position: absolute;
				height: 0px;
				width: 0px;
				background-color: transparent;;
				border: 4px solid rgba(10,10,10,0.5);
			}
		</style>
    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
  
  <style>
  img:not(.lazy) {
    height: auto;
}

img {
    max-width: 100%;
}
</style> <style type="text/css">
    /*
 *  Usage:
 *
      <div class="sk-circle">
        <div class="sk-circle1 sk-child"></div>
        <div class="sk-circle2 sk-child"></div>
        <div class="sk-circle3 sk-child"></div>
        <div class="sk-circle4 sk-child"></div>
        <div class="sk-circle5 sk-child"></div>
        <div class="sk-circle6 sk-child"></div>
        <div class="sk-circle7 sk-child"></div>
        <div class="sk-circle8 sk-child"></div>
        <div class="sk-circle9 sk-child"></div>
        <div class="sk-circle10 sk-child"></div>
        <div class="sk-circle11 sk-child"></div>
        <div class="sk-circle12 sk-child"></div>
      </div>
 *
 */
 .sk-circlen {
    width: 100%;
    height: 300%;
    text-align: center;
    position: absolute;
    opacity: .6;
    z-index: 100005;
    background: white;
    margin: 0px;
	}
.sk-circle {
    margin: 50% auto;
    width: 40px;
    height: 40px;
    position: relative;
    z-index: 1000; }
  .sk-circle .sk-child {
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0; }
  .sk-circle .sk-child:before {
    content: '';
    display: block;
    margin: 0 auto;
    width: 15%;
    height: 15%;
    background-color: #333;
    border-radius: 100%;
    -webkit-animation: sk-circleBounceDelay 1.2s infinite ease-in-out both;
            animation: sk-circleBounceDelay 1.2s infinite ease-in-out both; }
  .sk-circle .sk-circle2 {
    -webkit-transform: rotate(30deg);
        -ms-transform: rotate(30deg);
            transform: rotate(30deg); }
  .sk-circle .sk-circle3 {
    -webkit-transform: rotate(60deg);
        -ms-transform: rotate(60deg);
            transform: rotate(60deg); }
  .sk-circle .sk-circle4 {
    -webkit-transform: rotate(90deg);
        -ms-transform: rotate(90deg);
            transform: rotate(90deg); }
  .sk-circle .sk-circle5 {
    -webkit-transform: rotate(120deg);
        -ms-transform: rotate(120deg);
            transform: rotate(120deg); }
  .sk-circle .sk-circle6 {
    -webkit-transform: rotate(150deg);
        -ms-transform: rotate(150deg);
            transform: rotate(150deg); }
  .sk-circle .sk-circle7 {
    -webkit-transform: rotate(180deg);
        -ms-transform: rotate(180deg);
            transform: rotate(180deg); }
  .sk-circle .sk-circle8 {
    -webkit-transform: rotate(210deg);
        -ms-transform: rotate(210deg);
            transform: rotate(210deg); }
  .sk-circle .sk-circle9 {
    -webkit-transform: rotate(240deg);
        -ms-transform: rotate(240deg);
            transform: rotate(240deg); }
  .sk-circle .sk-circle10 {
    -webkit-transform: rotate(270deg);
        -ms-transform: rotate(270deg);
            transform: rotate(270deg); }
  .sk-circle .sk-circle11 {
    -webkit-transform: rotate(300deg);
        -ms-transform: rotate(300deg);
            transform: rotate(300deg); }
  .sk-circle .sk-circle12 {
    -webkit-transform: rotate(330deg);
        -ms-transform: rotate(330deg);
            transform: rotate(330deg); }
  .sk-circle .sk-circle2:before {
    -webkit-animation-delay: -1.1s;
            animation-delay: -1.1s; }
  .sk-circle .sk-circle3:before {
    -webkit-animation-delay: -1s;
            animation-delay: -1s; }
  .sk-circle .sk-circle4:before {
    -webkit-animation-delay: -0.9s;
            animation-delay: -0.9s; }
  .sk-circle .sk-circle5:before {
    -webkit-animation-delay: -0.8s;
            animation-delay: -0.8s; }
  .sk-circle .sk-circle6:before {
    -webkit-animation-delay: -0.7s;
            animation-delay: -0.7s; }
  .sk-circle .sk-circle7:before {
    -webkit-animation-delay: -0.6s;
            animation-delay: -0.6s; }
  .sk-circle .sk-circle8:before {
    -webkit-animation-delay: -0.5s;
            animation-delay: -0.5s; }
  .sk-circle .sk-circle9:before {
    -webkit-animation-delay: -0.4s;
            animation-delay: -0.4s; }
  .sk-circle .sk-circle10:before {
    -webkit-animation-delay: -0.3s;
            animation-delay: -0.3s; }
  .sk-circle .sk-circle11:before {
    -webkit-animation-delay: -0.2s;
            animation-delay: -0.2s; }
  .sk-circle .sk-circle12:before {
    -webkit-animation-delay: -0.1s;
            animation-delay: -0.1s; }

@-webkit-keyframes sk-circleBounceDelay {
  0%, 80%, 100% {
    -webkit-transform: scale(0);
            transform: scale(0); }
  40% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@keyframes sk-circleBounceDelay {
  0%, 80%, 100% {
    -webkit-transform: scale(0);
            transform: scale(0); }
  40% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

  </style>
  <style>
  #bcolor, #sample, #bprice, #sizecheck {
	height: 34px; 
width: 30%;	
  }
  .error {
	color:red;  
  }
  </style>
  <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<link rel="stylesheet" href="sweetalert.css">
<div class="sk-circlen" id="sk-circlen" style="display:none;">
<div class="sk-circle">
        <div class="sk-circle1 sk-child"></div>
        <div class="sk-circle2 sk-child"></div>
        <div class="sk-circle3 sk-child"></div>
        <div class="sk-circle4 sk-child"></div>
        <div class="sk-circle5 sk-child"></div>
        <div class="sk-circle6 sk-child"></div>
        <div class="sk-circle7 sk-child"></div>
        <div class="sk-circle8 sk-child"></div>
        <div class="sk-circle9 sk-child"></div>
        <div class="sk-circle10 sk-child"></div>
        <div class="sk-circle11 sk-child"></div>
        <div class="sk-circle12 sk-child"></div>
      </div></div>
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
           <?php include 'sidebar.php'; ?> <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <?php include 'top.php'; ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main" style="min-height:500px">
          <div class="">
            
            <div class="clearfix"></div>


          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include 'footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery --
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress --
    <script src="vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
<script>
document.getElementById("files").onchange = function () {
    var reader = new FileReader();

    reader.onload = function (e) {
    var image = new Image();
var height = "";
var width = "";
var size = "";
    image.src = reader.result;

    image.onload = function() {
        width = image.width;
        height = image.height;
		
		document.getElementById("image").innerHTML = "";
        document.getElementById("image").src = e.target.result;
	/**if(width<300) {
            $('#files').after('<span class="error">Please Image minimum width is 300px</span>');
		document.getElementById("files").value="";
	} else if (height != width) {
            $('#files').after('<span class="error">Please ensure that the height of your image equals the width</span>');
		document.getElementById("files").value="";
	} else {
        // get loaded data and render thumbnail.
		document.getElementById("image").innerHTML = "";
        document.getElementById("image").src = e.target.result;
	}*/
    };
    };

    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
};


document.getElementById("files2").onchange = function () {
    var reader = new FileReader();

    reader.onload = function (e) {  
	var image = new Image();
var height = "";
var width = "";
    image.src = reader.result;

    image.onload = function() {
        width = image.width;
        height = image.height;	
		
		document.getElementById("image2").innerHTML = "";
        document.getElementById("image2").src = e.target.result;
	/**if(width<300) {
            $('#files2').after('<span class="error">Please Image minimum width is 300px</span>');
		document.getElementById("files2").value="";
	} else if (height != width) {
            $('#files2').after('<span class="error">Please ensure that the height of your image equals the width</span>');
		document.getElementById("files2").value="";
	} else {
        // get loaded data and render thumbnail.
		document.getElementById("image2").innerHTML = "";
        document.getElementById("image2").src = e.target.result;
	}*/
    };
        // get loaded data and render thumbnail.
    };

    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
};

document.getElementById("files3").onchange = function () {
    var reader = new FileReader();

    reader.onload = function (e) {	
	var image = new Image();
var height = "";
var width = "";
    image.src = reader.result;

    image.onload = function() {
        width = image.width;
        height = image.height;

		document.getElementById("image3").innerHTML = "";
        document.getElementById("image3").src = e.target.result;		
	/**if(width<300) {
            $('#files3').after('<span class="error">Please Image minimum width is 300px</span>');
		document.getElementById("files3").value="";
	} else if (height != width) {
            $('#files3').after('<span class="error">Please ensure that the height of your image equals the width</span>');
		document.getElementById("files3").value="";
	} else {
        // get loaded data and render thumbnail.
		document.getElementById("image3").innerHTML = "";
        document.getElementById("image3").src = e.target.result;
	}*/
    };
        // get loaded data and render thumbnail.
    };

    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
};
function chgcol(n) {
 const preview = document.querySelector('#colorimage'+n);
  const file = document.querySelector('#color'+n).files[0];
  const reader = new FileReader();

  reader.addEventListener("load", function () {
    // convert image file to base64 string
    preview.src = reader.result;
  }, false);

  if (file) {
    reader.readAsDataURL(file);
}
}
</script>
<script>
$('#productform').on('submit', function(e) {
				e.preventDefault();
	   var pname = $('#pname').val();
	   var selectbulkprice=$('input[name="bprice"]:checked').val();
	   var selectbulkcolor=$('input[name="bcolor"]:checked').val();
	   var selectsample=$('input[name="sample"]:checked').val();
	   var totalbulkpricetr=$('#tbprice').val();
	   var totalbulkcolortr=$('#tbcolor').val();
	   var oprice = $('#price').val();
	   var weight = $('#weight').val();
	   var product_cat = $('#product_cat').val();
	   var product_scat = $('#product_scat').val();
	   var product_cccat = $('#product_cccat').val();
	   var des = CKEDITOR.instances.des.getData();
	   var size = $("#tags_1").val();
	var sizechck = $('input[name="sizecheck"]:checked').val();
	   var isValid = true;
	    var inputVal = new Array(pname,oprice,product_cat,des,product_scat,product_cccat,weight);

    var inputMessage = new Array("Product Name","Product Price","Product Category","Product Description","Product Subcategory","Product Category Class","Product Weight");
	$('#dokan-alert-warning').empty();
		if(inputVal[0] == ""){ 
		isValid = false;
            $('#pname').after('<span class="error"> Please Enter ' + inputMessage[0] + '</span>');
			$('#dokan-alert-warning').append('<strong>Error!</strong> Please Enter ' + inputMessage[1]+'<br/>');
        }
		if(selectbulkprice=="yes") {
	 for(var i=1; i<=totalbulkpricetr-1; i++) {
		var price = $('#bulkprice'+i).val(); 
		var min = $('#min'+i).val(); 
		var max = $('#max'+i).val(); 
		  var inputValn = new Array(price,min,max);
    var inputMessagen = new Array("Bulk Price","Minimum Quantity","Maximum Quantity");
	if(inputValn[0] == ""){ 
		isValid = false;
            $('#bulkpricetbl1').after('<span class="error control-label col-md-3 col-sm-3"> Please Enter a valid value in the ' + inputMessagen[0] + ' space or you can remove the field to continue</span>');
		
        }
		if(inputValn[0] == 0){ 
		isValid = false;
            $('#bulkpricetbl1').after('<span class="error control-label col-md-3 col-sm-3">' + inputMessagen[0] + ' value can not be zero</span>');
        }
		if(inputValn[1] == ""){ 
		isValid = false;
            $('#bulkpricetbl1').after('<span class="error control-label col-md-3 col-sm-3"> Please Enter the ' + inputMessagen[1] + '</span>');
        }
		if(inputValn[2] == ""){ 
		isValid = false;
            $('#bulkpricetbl1').after('<span class="error control-label col-md-3 col-sm-3"> Please Enter the ' + inputMessagen[2] + '</span>');
        }
	 }
	   } else {
		if(inputVal[1] == ""){ 
		isValid = false;
            $('#price').after('<span class="error"> Please Enter ' + inputMessage[1] + '</span>');
        }
		if(inputVal[1] == 0){ 
		isValid = false;
            $('#price').after('<span class="error">' + inputMessage[1] + ' value can not be zero</span>');
        }
	   }
		if(inputVal[6] == ""){ 
		isValid = false;
            $('#weight').after('<span class="error"> Please Enter ' + inputMessage[1] + '</span>');
        }
		if(inputVal[6] == 0){ 
		isValid = false;
            $('#weight').after('<span class="error">' + inputMessage[1] + ' value can not be zero</span>');
        }
	   
	   if(selectbulkcolor=="yes") {
	 for(var i=1; i<=totalbulkcolortr; i++) {
		var image = $('#color'+i).val(); 
		var colortitle = $('#colortitle'+i).val(); 
		  var inputValn = new Array(image,colortitle);
    var inputMessagen = new Array("Image Color","Color Name");
	if(inputValn[0] == ""){ 
		isValid = false;
            $('#bulkcolor1').after('<span class="error control-label col-md-3 col-sm-3"> Please select ' + inputMessagen[0] + ' space or you can remove the field to continue</span>');
		
        }
		if(inputValn[1] == ""){ 
		isValid = false;
            $('#bulkcolor1').after('<span class="error control-label col-md-3 col-sm-3"> Please Enter the ' + inputMessagen[1] + '</span>');
        }
		if(inputValn[2] == ""){ 
		isValid = false;
            $('#bulkpricetbl1').after('<span class="error control-label col-md-3 col-sm-3"> Please Enter the ' + inputMessagen[2] + '</span>');
        }
	 }
	   }
	   
	   if(selectsample=="yes") {
		var price = $('#sampleprice').val(); 
		var min = $('#samplemin1').val(); 
		  var inputValn = new Array(price,min);
    var inputMessagen = new Array("Price","Minimum Quantity");
	if(inputValn[0] == ""){ 
		isValid = false;
            $('#sampleprice').after('<span class="error"> Please enter ' + inputMessagen[0] + ' </span>');
		
        }
		if(inputValn[1] == ""){ 
		isValid = false;
            $('#samplemin1').after('<span class="error"> Please Enter the ' + inputMessagen[1] + '</span>');
        }
	 }
	 
	 if(sizechck=="yes") {
	var inputValn = new Array(size);
    var inputMessagen = new Array("Sizes");
	if(inputValn[0] == ""){ 
		isValid = false;
            $('#tags_1').after('<span class="error"> Please enter ' + inputMessagen[0] + ' </span>');
		
        }
		if(inputValn[1] == ""){ 
		isValid = false;
            $('#samplemin1').after('<span class="error"> Please Enter the ' + inputMessagen[1] + '</span>');
        }
	 }
	   
	   
		if(inputVal[2] == ""){ 
		isValid = false;
            $('#product_cat').after('<span class="error"> Please select ' + inputMessage[2] + '</span>');
			$('#dokan-alert-warning').append('<strong>Error!</strong> Please select ' + inputMessage[2]+'<br/>');
        }
		if(inputVal[3] == ""){ 
		isValid = false;
            $('#des').after('<span class="error"> Please produce ' + inputMessage[3] + '</span>');
			$('#dokan-alert-warning').append('<strong>Error!</strong> Please produce ' + inputMessage[3]+'<br/>');
        }
		

  if (isValid == false) {
                e.preventDefault();
            $('#dokan-alert-warning').css('display','block');
			} else {
				
            $('#sk-circlen').css('display','block');
			//var formd = $('#productform').serialize();
        var form = $('#productform')[0];

		// Create an FormData object 
        var data = new FormData(form);
		data.append('des', des);
		if(sizechck=="yes") {
		data.append('size', size);
		}
		
		   $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url:'imgupld1i.php',
        //url:'imgupld1i.php',
        data:data,
        processData: false,  // Important!
        contentType: false,
        cache: false,
        success:function(data) {
		var valData= data;
		var valNew=valData.split(']');
	    var des=valNew[1];
		if(des=="1"){
				$('.sweet-overlay').css('display','block');
				$('.sweet-overlay').css('opacity','1');
				$('.sweet-alert').removeClass('hideSweetAlert');
				$('.sweet-alert').addClass('showSweetAlert');
				$('.sweet-alert').addClass('visible');
				$('.sweet-alert').css('display','block');
				$('.sweet-alert').css('opacity','1');
            $('#sk-circlen').css('display','none');
				$('.confirm').on('click', function(e) {
					window.location.href="";
				});
			
		} else {
			$('#eed').empty();
			$('#eed2').empty();
            $('#sk-circlen').css('display','none');$('.sweet-overlay').css('display','block');
				$('.sweet-overlay').css('opacity','1');
				$('.sweet-alert').removeClass('hideSweetAlert');
				$('.sweet-alert').addClass('showSweetAlert');
				$('.sweet-alert').addClass('visible');
				$('.sweet-alert').css('display','block');
				$('.sweet-alert').css('opacity','1');
			$('#eed').append('<strong>Sorry an Error occured!</strong> <br/>');
			$('#eed2').append('' + des+'<br/>');
            $('#sk-circlen').css('display','none');
				$('.confirm').on('click', function(e) {
					window.location.href="";
				});
		}
        }
      });
}
});
	var rowCount = $('#tbulkprice tr').length;
$('#tbprice').val(rowCount);
if(rowCount<=1) {
$('#minus1').css('display','none');	
}
	var rowCountc = $('#bulkcolor tr').length;
$('#tbcolor').val(rowCountc);
if(rowCountc<=1) {
$('#minus2').css('display','none');	
}
function add1() {
	var rowCount1 = $('#bulkcolor tr').length+1;
$('#bulkcolor tr:last').after('<tr><th scope="row"><input type="file" id="color'+rowCount1+'" onchange="chgcol('+rowCount1+')" name="imagecolor'+rowCount1+'" /></th><td><img id="colorimage'+rowCount1+'" height="30" width="30" /></td><td><input type="text" id="colortitle'+rowCount1+'" class="form-control col-md-7 col-xs-12" name="colortitle'+rowCount1+'" value="" placeholder="Color Title"/></td></tr>');
$('#tbcolor').val(rowCount1);
if(rowCount1<=1) {
$('#minus2').css('display','none');	
} else {
$('#minus2').css('display','block');		
}
}
function add2() {
	var rowCount = $('#tbulkprice tr').length+1;
$('#tbulkprice tr:last').after('<tr><th scope="row"><input type="number" class="form-control col-md-7 col-xs-12" id="bulkprice'+rowCount+'" name="bulkprice'+rowCount+'" value="" placeholder="0.00" min="0" step="any"/></th><td><input type="text" id="min'+rowCount+'" class="form-control col-md-7 col-xs-12" name="min'+rowCount+'" value=""/></td><td><input type="text" id="max'+rowCount+'" class="form-control col-md-7 col-xs-12" name="max'+rowCount+'" value=""/></td></tr>');
$('#tbprice').val(rowCount);
if(rowCount<=1) {
$('#minus1').css('display','none');	
} else {
$('#minus1').css('display','block');		
}
}
function remove2() {
	var rowCount = $('#tbulkprice tr').length;
	var rowCountm = rowCount-1
$('#tbulkprice tr:last').remove();
$('#tbprice').val(rowCountm);
if(rowCountm==1) {
$('#minus1').css('display','none');	
}
}  
function remove1() {
	var rowCount1 = $('#bulkcolor tr').length-1;
$('#bulkcolor tr:last').remove();
$('#tbcolor').val(rowCount1);
if(rowCount1==1) {
$('#minus2').css('display','none');	
}
} 
$('#bprice').click(function() {
	var chck = $('input[name="bprice"]:checked').val();
	if(chck=="yes"){
		$('#lbprice').css('display','none');
		$('#inprice').css('display','none');
		$('#bulkpricetbl').css('display','block');
	} else {
		$('#lbprice').css('display','block');
		$('#inprice').css('display','block');
		$('#bulkpricetbl').css('display','none');
	}
});
$('#sizecheck').click(function() {
	var chck = $('input[name="sizecheck"]:checked').val();
	if(chck=="yes"){
		$('#sizetbl').css('display','block');
	} else {
		$('#sizetbl').css('display','none');
	}
});
$('#sample').click(function() {
	var chck = $('input[name="sample"]:checked').val();
	if(chck=="yes"){
		$('#sampletbl').css('display','block');
	} else {
		$('#sampletbl').css('display','none');
	}
});
$('#bcolor').click(function() {
	var chck = $('input[name="bcolor"]:checked').val();
	if(chck=="yes"){
		$('#bulkcolortbl').css('display','block');
	} else {
		$('#bulkcolortbl').css('display','none');
	}
});
//$('#tableBody').children('tr').remove();
function getsub() {
	var level = $('#product_cat').val();
	var leveld = $('#product_cccat').val();
	  	$.ajax({
        type:'post',
        url:'getsub.php',
        data:{
			leveln:level,
			levelnd:leveld
        },
        success:function(response) {
		var valData= response;
		var valNew=valData.split(']');
	    var noti=valNew[2];
	    var resp=valNew[1];
		$('#product_scat').empty();
		$('#product_scat').append(noti);
		if(resp==""){ $('#fsub').css('display','none'); } else { $('#fsub').css('display','block');}

        }
      });
}function getdiv() {
	var level = $('#product_cat').val();
	  	$.ajax({
        type:'post',
        url:'getsub.php',
        data:{
			levelnd:level
        },
        success:function(response) {
		var valData= response;
		var valNew=valData.split(']');
	    var noti=valNew[2];
	    var resp=valNew[1];
		$('#product_cccat').empty();
		$('#product_cccat').append(noti);
		if(resp==""){ $('#fclss').css('display','none');} else { $('#fclss').css('display','block');}

        }
      });
}
</script>
  </body>
</html>