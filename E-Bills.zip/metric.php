<?php
session_start();
if(isset($_GET['sort']) && ($_GET['sort']=="upload")) {

$ch = curl_init();
$certificate_location = 'cacert.pem';

curl_setopt($ch, CURLOPT_URL,"https://localhost:44382/api/UploadPIPMAPs");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "lvl=");
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));

// receive server response ...
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

echo $server_output = curl_exec ($ch);
curl_close ($ch);
 $array = json_decode($server_output, true); 
}


if(isset($_GET['sort']) && ($_GET['sort']=="metric")) {
    $authorization = "Authorization: Bearer ".$_SESSION['MM_Username1'];   
      //SEND DATA TO API
      //$jsonArrayRequest = json_encode($postRequest);
      //$jsonArrayRequest = json_encode($postRequest);
      $cURLConnection = curl_init('https://signals-api.staging.vggdev.com/extintegration/metrics/');
      $certificate_location = 'cacert.pem';
      curl_setopt($cURLConnection, CURLOPT_HTTPHEADER, array('Content-Type: application/json' , $authorization ));
      //curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, "");
      curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($cURLConnection, CURLOPT_SSL_VERIFYHOST, $certificate_location);
      curl_setopt($cURLConnection, CURLOPT_SSL_VERIFYPEER, $certificate_location);
      
       echo $apiResponse = curl_exec($cURLConnection);
      curl_close($cURLConnection);
      
      // $apiResponse - available data from the API request
      $jsonArrayResponse = json_decode($apiResponse);
        $array = json_decode($apiResponse, true);
     
}


if(isset($_GET['sort']) && ($_GET['sort']=="kpi")) {
    $authorization = "Authorization: Bearer ".$_SESSION['MM_Username1'];   
      //SEND DATA TO API
      //$jsonArrayRequest = json_encode($postRequest);
      //$jsonArrayRequest = json_encode($postRequest);
      $cURLConnection = curl_init('https://signals-api.staging.vggdev.com/extintegration/kpi/');
      $certificate_location = 'cacert.pem';
      curl_setopt($cURLConnection, CURLOPT_HTTPHEADER, array('Content-Type: application/json' , $authorization ));
      //curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, "");
      curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($cURLConnection, CURLOPT_SSL_VERIFYHOST, $certificate_location);
      curl_setopt($cURLConnection, CURLOPT_SSL_VERIFYPEER, $certificate_location);
      
       echo $apiResponse = curl_exec($cURLConnection);
      curl_close($cURLConnection);
      
      // $apiResponse - available data from the API request
      $jsonArrayResponse = json_decode($apiResponse);
        $array = json_decode($apiResponse, true);
     
}

?>