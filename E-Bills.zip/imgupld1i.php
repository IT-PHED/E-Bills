<?php
session_start();
require_once('Connections/conKachi.php');
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username1'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username1']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
  unset($_SESSION['name']);
	
  $logoutGoTo = "Login";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}

$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}
if(isset($_POST['des']))
{
   echo $des=$_POST['des'];
   $info=mysqli_real_escape_string($conKachi,$_POST['des']);
   $size="";//mysqli_real_escape_string($conKachi,$_POST['size']);
   $pname=mysqli_real_escape_string($conKachi,$_POST['pname']);
  $track="";
   $price=mysqli_real_escape_string($conKachi,$_POST['price']);
   $weight=mysqli_real_escape_string($conKachi,$_POST['weight']);
   $oprice="";//mysqli_real_escape_string($conKachi,$_POST['oprice']);
   $brand="";//mysqli_real_escape_string($conKachi,$_POST['brand']);
   $pcat=mysqli_real_escape_string($conKachi,$_POST['product_scat']);
   $seller=mysqli_real_escape_string($conKachi,$_SESSION['MM_Username1']);
   $totalprice=mysqli_real_escape_string($conKachi,$_POST['tbprice']);
   $totalcolor=mysqli_real_escape_string($conKachi,$_POST['tbcolor']);
   $selectbulkprice="";//mysqli_real_escape_string($conKachi,$_POST['bprice']);
   $selectbulkcolor="";//mysqli_real_escape_string($conKachi,$_POST['bcolor']);
   $hassample="";//mysqli_real_escape_string($conKachi,$_POST['sample']);
     if(isset($_POST['product_cccat'])) {
   $product_cccat=mysqli_real_escape_string($conKachi,$_POST['product_cccat']);
	 }
   $product_scat="";
     if(isset($_POST['product_scat'])) {
   $product_scat=mysqli_real_escape_string($conKachi,$_POST['product_scat']);
	 }
   $cat="";
     if(isset($_POST['product_cat'])) {
   $cat=mysqli_real_escape_string($conKachi,$_POST['product_cat']);
	 }
   $base642="";
   $base643="";
   $pid="";

$code="";
  $track=$code;
    $errors=array();
    $allowed_ext= array('jpg','jpeg','png','gif');
    $file_name =$_FILES['image']['name'];
 //   $file_name =$_FILES['image']['tmp_name'];
  //  $file_ext = strtolower(explode('.',$file_name));


    $file_size=$_FILES['image']['size'];
    $file_tmp= $_FILES['image']['tmp_name'];
     $file_tmp;echo "<br>";

    $type = pathinfo($file_tmp, PATHINFO_EXTENSION);
    $data = file_get_contents($file_tmp);
   // $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
   //   "Base64 is ".$base64;
$target_dir = "../uploads/";
$target_dir2 = "uploads/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);
$target_file2 = $target_dir2 . basename($_FILES["image"]["name"]);
$uploadOk = 1;
$base64 = $target_file2;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	   if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
   }


 echo   $file_name2 =$_FILES['image2']['name'];


    $file_size2=$_FILES['image2']['size'];
    $file_tmp2= $_FILES['image2']['tmp_name'];
     $file_tmp2;echo "<br>";

    $type2 = pathinfo($file_tmp2, PATHINFO_EXTENSION);
    $data2 = file_get_contents($file_tmp2);
    //$base642 = 'data:image/' . $type2 . ';base64,' . base64_encode($data2);
	$target_dir = "../uploads/";
	$target_dir2 = "uploads/";
$target_file = $target_dir . basename($_FILES["image2"]["name"]);
$target_file2 = $target_dir2 . basename($_FILES["image2"]["name"]);
$uploadOk = 1;
$base642 = $target_file2;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	   if (move_uploaded_file($_FILES["image2"]["tmp_name"], $target_file)) {
   
   }
	

/*if($_FILES['image3']['size'] != 0 && $_FILES['image3']['error'] != 0)
{
    $file_name3 =$_FILES['image3']['name'];


    $file_size3=$_FILES['image3']['size'];
    $file_tmp3= $_FILES['image3']['tmp_name'];
     $file_tmp3;echo "<br>";

    $type3 = pathinfo($file_tmp3, PATHINFO_EXTENSION);
    $data3 = file_get_contents($file_tmp3);
   // $base643 = 'data:image/' . $type3 . ';base64,' . base64_encode($data3);
   $target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);
$uploadOk = 1;
$base643 = $target_file;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	   if (move_uploaded_file($_FILES["image3"]["tmp_name"], $target_file)) {
	$insertSQL = "INSERT INTO tbl_pro_img (track, img_url) VALUES ('$track','$base643')" ;                
  mysqli_select_db($conKachi, $database_conKachi);
  $Result2 = mysqli_query($conKachi, $insertSQL) or die(mysqli_error($conKachi)); 
   
   }
	
}*/

//2097152
    if($file_size > 1000000)
    {
        $errors[]= 'File size must be under 1mb';

    }
    if(empty($errors))
    {
        
  $insertSQL = "INSERT INTO collectionz (pname, des, price, img_url, ani_img_url, cat) VALUES ('$pname', '$des',  '$price', '$base64', '$base642', '$cat')" ;                
  mysqli_select_db($conKachi, $database_conKachi);
  $Result1 = mysqli_query($conKachi, $insertSQL) or die(mysqli_error($conKachi));
 echo 'pid'. $pid=mysqli_insert_id($conKachi);
  
  if($Result1){
	//header('location:?suc=1'); 
	echo ']1';
  }
    
    }
    else
    {
        foreach($errors as $error)
        {
          // header('location:Error');
echo ']'.$error;		  
        }
    }
   //  print_r($errors);

}
?>