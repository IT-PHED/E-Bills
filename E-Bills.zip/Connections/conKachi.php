<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_conKachi = "localhost";
$database_conKachi = "smac";
$username_conKachi = "root";
$password_conKachi = "";
$conKachi = mysqli_connect($hostname_conKachi, $username_conKachi, $password_conKachi) or trigger_error(mysqli_error($conKachi),E_USER_ERROR); 
?>