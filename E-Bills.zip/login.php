<?php require_once('Connections/conKachi.php'); ?>
<?php 
session_start();
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=$_POST['password'];
  echo $password=sha1($password);
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "buyerdash.php";
  $MM_redirectLoginFailed = "login.php?vl=001n";
  $MM_redirecttoReferrer = false;
  mysqli_select_db($conKachi, $database_conKachi);
  
  $LoginRS__query=sprintf("SELECT user, pass FROM admin_user WHERE (user='$loginUsername') AND pass=%s",
 GetSQLValueString($password, "text")); 
   
  $LoginRS = mysqli_query($conKachi,$LoginRS__query) or die(mysqli_error($conKachi));
  $row_LoginRS = mysqli_fetch_assoc($LoginRS);;
  $loginFoundUser = mysqli_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username1'] = $row_LoginRS['user'];
    $_SESSION['MM_UserGroup1'] = $loginStrGroup;	      

    	$colname_Recordset1 = "-1";
if (isset($_SESSION['MM_Username1'])) {
  $colname_Recordset1 = $_SESSION['MM_Username1'] ;
}
header('location:./');
  } else {
	header('location:login.php?vl=001n');  
  }
}
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>PIPMAPs</title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
	<link href="build/css/custom.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css" rel="stylesheet" />
    <link href="build/css/custom.min.css" rel="stylesheet">    
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action ="" method="POST">
              <h1>Login</h1>
              <div>
                <input type="text" class="form-control" id="user" name="username" placeholder="Staff Email" required="" />
              </div>
              <div>
                <input type="password" class="form-control" id="password"  name="password" placeholder="Password" required="" />
              </div>
              <div>
                <button class="btn btn-default submit" type="button" onclick ="login()" >Log in</button>
                <a class="reset_pass" href="#">Lost your password?</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">New to site?
                  <a href="#signup" class="to_register"> Create Account </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1> SMACHOF</h1>
                </div>
              </div>
            </form>
          </section>
        </div>

        <div id="register" class="animate form registration_form">
          <section class="login_content">
            <form>
              <h1>Onboard Account</h1>
			  <div id="d1">
              <div>
                <input type="email" id="email" class="form-control" placeholder="Email" required="" />
              </div>
              <div>
                <input type="password" id="pass" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <a class="btn btn-default submit" href="javascript:void(0)" onclick="getdetails()">Verify Account</a>
              </div>
			  </div>
			  
			  <div id="d2" style="display:none">
              <div>
                <input type="text" class="form-control" readonly id="name1" placeholder="Staff Name" required="" />
              </div>
              <div>
                <input type="email" id="email1" class="form-control" placeholder="Email" required="" />
              </div>
              <div>
                <input type="password" id="pass1" class="form-control" placeholder="Transformer Password" required="" />
              </div>
              <div>
                <input type="text" id="zone1" class="form-control" readonly placeholder="Zone" required="" />
              </div>
              <div>
                <a class="btn btn-default submit" href="javascript:void(0)" onclick="getdetails2()">Submit</a>
              </div>
			  </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="#signin" class="to_register"> Log in </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1> SMACHOF</h1>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
	<!-- jQuery -->
	<script src="vendors/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap -->
	<script src="vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
	<!-- FastClick -->
	<script src="vendors/fastclick/lib/fastclick.js"></script>
	<!-- NProgress -->
	<script src="vendors/nprogress/nprogress.js"></script>
	<!-- bootstrap-progressbar -->
	<script src="vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
	<!-- iCheck -->
	<script src="vendors/iCheck/icheck.min.js"></script>
	<!-- bootstrap-daterangepicker -->
	<script src="vendors/moment/min/moment.min.js"></script>
	<script src="vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
	<!-- bootstrap-wysiwyg -->
	<script src="vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
	<script src="vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
	<script src="vendors/google-code-prettify/src/prettify.js"></script>
	<!-- jQuery Tags Input -->
	<script src="vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
	<!-- Switchery -->
	<script src="vendors/switchery/dist/switchery.min.js"></script>
	<!-- Select2 -->
	<script src="vendors/select2/dist/js/select2.full.min.js"></script>
	<!-- Parsley -->
	<script src="vendors/parsleyjs/dist/parsley.min.js"></script>
	<!-- Autosize -->
	<script src="vendors/autosize/dist/autosize.min.js"></script>
	<!-- jQuery autocomplete -->
	<script src="vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
	<!-- starrr -->
	<script src="vendors/starrr/dist/starrr.js"></script>
	<!-- Custom Theme Scripts -->
  <script>
    
	  function login() {
			var email = $('#user').val();
		var password = $('#password').val();

	   $('#sk-circlen').css('display','block');
			 swal({
                title: "Loading...",
                text: "Please wait",
                imageUrl: 'http://phedpayments.nepamsonline.com/images/loader4.gif',

                showConfirmButton: false,
                allowOutsideClick: false
            });

        $('#sk-circlen').css('display','block');	
		
$.ajax({
        type:'post',
        url:'api.php',
         data: {
		email  :email,
		password:password,
action:"login"
                },
        success:function(data) {
		alert(data);
		var valData= data;
		var valNew=valData.split(']');	
	     des=valNew[1];
		 if(des=="1"){
			 window.location.href="./";
		 }  else if (des=="zz") {
       		 swal({title: "Unable to verify your login", text: "Please ensure that you have been onboarded on insight", type: "warning"},
   function(){ 
       window.location.href="./Login";
   }
); 			 
		 } else {
					        $('#sk-circlen').css('display','none');	
    		 swal({title: "Login Failed", text: "Unable to login", type: "warning"},
   function(){ 
       window.location.href="./Login";
   }
); 
		 }

 }
      });
	  
		  
	  }
	  </script>
  </body>
</html>
